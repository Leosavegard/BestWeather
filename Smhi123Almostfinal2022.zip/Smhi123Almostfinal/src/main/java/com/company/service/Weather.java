package com.company.service;


public class Weather {
    Double temperature;
    Double wind;



    public Weather(Double temperature, Double wind) {
        this.temperature = temperature;
        this.wind = wind;
    }


    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Double getWind() {
        return wind;
    }

    public void setWind(Double wind) {
        this.wind = wind;
    }








    @Override
    public String toString() {
        return "The weather in 24 hours in Liljeholmen: " + "\nTemperature: " + temperature + "°C" + "\nWindspeed: " + wind + "m/s";
    }
}
