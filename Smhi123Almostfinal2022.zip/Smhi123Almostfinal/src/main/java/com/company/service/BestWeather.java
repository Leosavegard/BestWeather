package com.company.service;


import com.company.dao.met.MetService;
import com.company.dao.meteo.MeteoService;
import com.company.dao.smhi.SmhiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;


@Service
public class BestWeather {

    @Autowired
    SmhiService smhi;

    @Autowired
    MetService met;

    @Autowired
    MeteoService meteo;


    @PostConstruct
    public void init() {

        System.out.println("****" + smhi.getWeather().temperature);

    }

    public BestWeather() {
        System.out.println("hallå");
    }

    public Weather theBestWeather() {

        Weather smhiWeather;
        Weather metWeather;
        Weather meteoWeather;

        System.out.println(smhi);




        smhiWeather = smhi.getWeather();
        metWeather = met.getWeather();
        meteoWeather = meteo.getWeather();

        Weather best = smhiWeather;

        System.out.println(smhiWeather);
        System.out.println(metWeather);
        System.out.println(meteoWeather);

        if (smhiWeather.getTemperature() < metWeather.getTemperature()) {
            return best = metWeather;
        } else if (smhiWeather.getTemperature() == metWeather.getTemperature() && metWeather.getWind() < smhiWeather.getWind()) {
            return best = metWeather;
        }


        if (best.getTemperature() < meteoWeather.getTemperature()) {
            return best = meteoWeather;
        } else if (best.getTemperature() == metWeather.getTemperature() && best.getWind() > meteoWeather.getWind()) {
            return best = meteoWeather;
        }

        return best;
    }
}





