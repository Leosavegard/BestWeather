package com.company.controller;

import com.company.dao.WeatherDao;
import com.company.service.BestWeather;
import com.company.service.Weather;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {

    @Autowired
    BestWeather bestWeather;

    @GetMapping("")
    public String showHomePage() {
        return "index";

    }

    @GetMapping("/bestw")
    public String bestWeather(Model model) {

        Weather weather = bestWeather.theBestWeather();
        model.addAttribute("weather", weather);
        return "bestweather";
    }

}
