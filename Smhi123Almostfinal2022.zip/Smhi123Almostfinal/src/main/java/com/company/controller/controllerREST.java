package com.company.controller;



import com.company.service.BestWeather;
import com.company.service.Weather;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class controllerREST {

    @Autowired
    BestWeather bestWeather;

    @GetMapping("/best")
    public Weather getBestWeather(){

        return bestWeather.theBestWeather();
    }



}
