package com.company;


import com.company.dao.met.MetService;
import com.company.dao.meteo.MeteoService;
import com.company.dao.smhi.SmhiService;
import com.company.service.BestWeather;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringRunMain {


    public static void main(String[] args) {

        SpringApplication.run(SpringRunMain.class, args);

       /* MeteoService meteoService = new MeteoService();
        MetService metService = new MetService();
        SmhiService service = new SmhiService();
        BestWeather bestWeather = new BestWeather();

        System.out.println(meteoService.getWeather().getTemperature());
        System.out.println(meteoService.getWeather().getWind());
        System.out.println("************************************");
        System.out.println(metService.getWeather().getTemperature());
        System.out.println(metService.getWeather().getWind());
        System.out.println("************************************");
        System.out.println(service.getWeather().getTemperature());
        System.out.println(service.getWeather().getWind());
        System.out.println("************************************");
        System.out.println(bestWeather.theBestWeather());*/


        }

        }












