package com.company.dao.smhi;

import com.company.dao.WeatherDao;
import com.company.service.Weather;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.annotation.ApplicationScope;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class SmhiService implements WeatherDao {
    @Override
    public Weather getWeather() {



        Double temperature = 0.0;
        Double windspeed = 0.0;

        Weather smhiW = new Weather(temperature, windspeed); //ska innehålla temperature, windspeed


        RestTemplate rt = new RestTemplateBuilder()
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader(HttpHeaders.USER_AGENT, "notJava!")
                .build();
        String baseUrl = "https://opendata-download-metfcst.smhi.se/api/category/pmp3g/version/2/geotype/point/lon/18.0300/lat/59.3110/data.json";


        Smhi smhiWeather = rt.getForObject(baseUrl, Smhi.class);
        Instant instant = Instant.now().truncatedTo(ChronoUnit.HOURS);

        List<TimeSeries> timeSeriesList = smhiWeather.getTimeSeries();

        for (TimeSeries timeseries : timeSeriesList) {

            if (Instant.parse(timeseries.getValidTime()).equals(instant.plus(24, ChronoUnit.HOURS))) {
                //System.out.println(timeseries.getValidTime());

                for (Parameter param : timeseries.getParameters()) {
                    if (param.getName().equals("t")) {

                        for (Double value : param.getValues()) {
                            smhiW.setTemperature(value);

                        }


                    }
                }

                for (Parameter param2 : timeseries.getParameters()) {

                    if (param2.getName().equals("ws")) {


                        for (Double value : param2.getValues()) {


                            smhiW.setWind(value);


                        }

                    }

                }

            }

        }

        return smhiW;
    }


}
