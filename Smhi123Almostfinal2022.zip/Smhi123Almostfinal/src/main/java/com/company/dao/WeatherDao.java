package com.company.dao;

import com.company.service.Weather;

public interface WeatherDao {

    Weather getWeather();
}

