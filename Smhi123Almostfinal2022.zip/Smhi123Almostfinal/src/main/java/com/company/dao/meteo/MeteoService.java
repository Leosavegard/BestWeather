package com.company.dao.meteo;

import com.company.dao.WeatherDao;
import com.company.service.Weather;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;

@Service
public class MeteoService implements WeatherDao {
    @Override
    public Weather getWeather() {

        RestTemplate rt = new RestTemplateBuilder()
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader(HttpHeaders.USER_AGENT, "notJava!")
                .build();

        String baseUrl = "https://api.open-meteo.com/v1/forecast?latitude=59.3110&longitude=18.0300&hourly=temperature_2m,windspeed_10m&windspeed_unit=ms";

        LocalDateTime ldtn = LocalDateTime.now(ZoneOffset.UTC).plusHours(24);
        DateTimeFormatter dtf1 = DateTimeFormatter.ISO_DATE_TIME;



        Meteo meteo = rt.getForObject(baseUrl, Meteo.class);

        List<String> timelist = meteo.getHourly().getTime();
        List<Double> temp = meteo.getHourly().getTemperature2m();
        List<Double> wind = meteo.getHourly().getWindspeed10m();


        String[] myArray = new String[timelist.size()];
        Double[] myArray2 = new Double[temp.size()];
        Double[] myArray3 = new Double[wind.size()];




        temp.toArray(myArray2);
        wind.toArray(myArray3);
        timelist.toArray(myArray);

        Double temperature = 0.0;
        Double windArray = 0.0;

        int number = 0;

        for (int i = 0; i < myArray.length; i++) {
            if ((myArray[i] + ":00").equals(ldtn.truncatedTo(ChronoUnit.HOURS).format(dtf1))) {

                number = i;

            }
        }

        temperature = myArray2[number];
        windArray = myArray3[number];



       return new Weather(temperature, windArray);

    }
}
