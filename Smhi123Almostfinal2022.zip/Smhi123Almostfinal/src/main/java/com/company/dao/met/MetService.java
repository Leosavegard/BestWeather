package com.company.dao.met;

import com.company.dao.WeatherDao;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.company.service.Weather;
import org.springframework.web.context.annotation.ApplicationScope;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
@Service
public class MetService implements WeatherDao {

    @Override
    public Weather getWeather() {

        RestTemplate rt = new RestTemplateBuilder()
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader(HttpHeaders.USER_AGENT, "notJava!")
                .build();
        String baseUrl = "https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=59.3110&lon=18.0300";

        LocalDateTime ldtn = LocalDateTime.now(ZoneOffset.UTC).plusHours(24);
        DateTimeFormatter dtf1 = DateTimeFormatter.ISO_DATE_TIME;
       // System.out.println(ldtn.truncatedTo(ChronoUnit.HOURS).format(dtf1));


        NorwayWeather weather = rt.getForObject(baseUrl, NorwayWeather.class);
        List<Timeseries> timeseriesList = weather.getProperties().getTimeseries();

        Double temp = 0.0;
        Double ws = 0.0;


        for (Timeseries timeseries : timeseriesList) {
            if (timeseries.getTime().equals(ldtn.truncatedTo(ChronoUnit.HOURS).format(dtf1) + "Z")) {
                temp = timeseries.getData().getInstant().getDetails().getAirTemperature();
                ws = timeseries.getData().getInstant().getDetails().getWindSpeed();
            }


        }

        return new Weather(temp,ws);

    }
}



